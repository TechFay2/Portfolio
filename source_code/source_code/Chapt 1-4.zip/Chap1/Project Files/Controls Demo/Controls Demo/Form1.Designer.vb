﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Frame2 = New System.Windows.Forms.GroupBox()
        Me.cboPets = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblPet = New System.Windows.Forms.Label()
        Me.lblOption = New System.Windows.Forms.Label()
        Me.lblHScrollValue = New System.Windows.Forms.Label()
        Me.Frame4 = New System.Windows.Forms.GroupBox()
        Me.radOption1 = New System.Windows.Forms.RadioButton()
        Me.radOption3 = New System.Windows.Forms.RadioButton()
        Me.radOption2 = New System.Windows.Forms.RadioButton()
        Me.lstVegetables = New System.Windows.Forms.ListBox()
        Me.chkCheckBox = New System.Windows.Forms.CheckBox()
        Me.vsbVertical = New System.Windows.Forms.VScrollBar()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblVegetable = New System.Windows.Forms.Label()
        Me.lblVScrollValue = New System.Windows.Forms.Label()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.hsbHorizontal = New System.Windows.Forms.HScrollBar()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.Frame3 = New System.Windows.Forms.GroupBox()
        Me.Frame5 = New System.Windows.Forms.GroupBox()
        Me.Frame2.SuspendLayout()
        Me.Frame4.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.Frame1.SuspendLayout()
        Me.Frame3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Frame2
        '
        Me.Frame2.BackColor = System.Drawing.SystemColors.Control
        Me.Frame2.Controls.Add(Me.cboPets)
        Me.Frame2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame2.Location = New System.Drawing.Point(25, 60)
        Me.Frame2.Name = "Frame2"
        Me.Frame2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame2.Size = New System.Drawing.Size(129, 73)
        Me.Frame2.TabIndex = 133
        Me.Frame2.TabStop = False
        Me.Frame2.Text = "ComboBox"
        '
        'cboPets
        '
        Me.cboPets.BackColor = System.Drawing.SystemColors.Window
        Me.cboPets.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboPets.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboPets.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboPets.Items.AddRange(New Object() {"Dog", "Cat", "Iguana", "Parrot", "Tarantula", "Llama", "Pony"})
        Me.cboPets.Location = New System.Drawing.Point(16, 25)
        Me.cboPets.Name = "cboPets"
        Me.cboPets.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboPets.Size = New System.Drawing.Size(97, 22)
        Me.cboPets.TabIndex = 25
        Me.cboPets.Text = "Choose a Pet"
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(21, 14)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(449, 33)
        Me.Label4.TabIndex = 146
        Me.Label4.Text = "Experiment with These Controls"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblPet
        '
        Me.lblPet.BackColor = System.Drawing.SystemColors.Control
        Me.lblPet.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblPet.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPet.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblPet.Location = New System.Drawing.Point(41, 156)
        Me.lblPet.Name = "lblPet"
        Me.lblPet.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblPet.Size = New System.Drawing.Size(97, 17)
        Me.lblPet.TabIndex = 143
        Me.lblPet.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblOption
        '
        Me.lblOption.BackColor = System.Drawing.SystemColors.Control
        Me.lblOption.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblOption.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOption.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblOption.Location = New System.Drawing.Point(25, 316)
        Me.lblOption.Name = "lblOption"
        Me.lblOption.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblOption.Size = New System.Drawing.Size(97, 24)
        Me.lblOption.TabIndex = 140
        Me.lblOption.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblHScrollValue
        '
        Me.lblHScrollValue.BackColor = System.Drawing.SystemColors.Control
        Me.lblHScrollValue.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblHScrollValue.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHScrollValue.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblHScrollValue.Location = New System.Drawing.Point(205, 254)
        Me.lblHScrollValue.Name = "lblHScrollValue"
        Me.lblHScrollValue.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblHScrollValue.Size = New System.Drawing.Size(113, 17)
        Me.lblHScrollValue.TabIndex = 138
        Me.lblHScrollValue.Text = "Move the Scroll Bar"
        Me.lblHScrollValue.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Frame4
        '
        Me.Frame4.BackColor = System.Drawing.SystemColors.Control
        Me.Frame4.Controls.Add(Me.radOption1)
        Me.Frame4.Controls.Add(Me.radOption3)
        Me.Frame4.Controls.Add(Me.radOption2)
        Me.Frame4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame4.Location = New System.Drawing.Point(17, 188)
        Me.Frame4.Name = "Frame4"
        Me.Frame4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame4.Size = New System.Drawing.Size(145, 96)
        Me.Frame4.TabIndex = 139
        Me.Frame4.TabStop = False
        Me.Frame4.Text = "RadioButtons"
        '
        'radOption1
        '
        Me.radOption1.BackColor = System.Drawing.SystemColors.Control
        Me.radOption1.Cursor = System.Windows.Forms.Cursors.Default
        Me.radOption1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radOption1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.radOption1.Location = New System.Drawing.Point(24, 24)
        Me.radOption1.Name = "radOption1"
        Me.radOption1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.radOption1.Size = New System.Drawing.Size(81, 20)
        Me.radOption1.TabIndex = 41
        Me.radOption1.TabStop = True
        Me.radOption1.Text = "Option 1"
        Me.radOption1.UseVisualStyleBackColor = False
        '
        'radOption3
        '
        Me.radOption3.BackColor = System.Drawing.SystemColors.Control
        Me.radOption3.Cursor = System.Windows.Forms.Cursors.Default
        Me.radOption3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radOption3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.radOption3.Location = New System.Drawing.Point(24, 72)
        Me.radOption3.Name = "radOption3"
        Me.radOption3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.radOption3.Size = New System.Drawing.Size(81, 20)
        Me.radOption3.TabIndex = 40
        Me.radOption3.TabStop = True
        Me.radOption3.Text = "Option 3"
        Me.radOption3.UseVisualStyleBackColor = False
        '
        'radOption2
        '
        Me.radOption2.BackColor = System.Drawing.SystemColors.Control
        Me.radOption2.Cursor = System.Windows.Forms.Cursors.Default
        Me.radOption2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radOption2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.radOption2.Location = New System.Drawing.Point(24, 48)
        Me.radOption2.Name = "radOption2"
        Me.radOption2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.radOption2.Size = New System.Drawing.Size(81, 20)
        Me.radOption2.TabIndex = 39
        Me.radOption2.TabStop = True
        Me.radOption2.Text = "Option 2"
        Me.radOption2.UseVisualStyleBackColor = False
        '
        'lstVegetables
        '
        Me.lstVegetables.BackColor = System.Drawing.SystemColors.Window
        Me.lstVegetables.Cursor = System.Windows.Forms.Cursors.Default
        Me.lstVegetables.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstVegetables.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lstVegetables.ItemHeight = 14
        Me.lstVegetables.Items.AddRange(New Object() {"Beans", "Broccoli", "Carrots", "Lettuce", "Peas", "Squash"})
        Me.lstVegetables.Location = New System.Drawing.Point(16, 22)
        Me.lstVegetables.Name = "lstVegetables"
        Me.lstVegetables.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lstVegetables.Size = New System.Drawing.Size(89, 60)
        Me.lstVegetables.Sorted = True
        Me.lstVegetables.TabIndex = 28
        '
        'chkCheckBox
        '
        Me.chkCheckBox.BackColor = System.Drawing.SystemColors.Control
        Me.chkCheckBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkCheckBox.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkCheckBox.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkCheckBox.Location = New System.Drawing.Point(12, 16)
        Me.chkCheckBox.Name = "chkCheckBox"
        Me.chkCheckBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkCheckBox.Size = New System.Drawing.Size(113, 33)
        Me.chkCheckBox.TabIndex = 24
        Me.chkCheckBox.Text = "The Check Box is un-checked"
        Me.chkCheckBox.UseVisualStyleBackColor = False
        '
        'vsbVertical
        '
        Me.vsbVertical.Location = New System.Drawing.Point(32, 24)
        Me.vsbVertical.Name = "vsbVertical"
        Me.vsbVertical.Size = New System.Drawing.Size(17, 80)
        Me.vsbVertical.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(49, 140)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(89, 16)
        Me.Label2.TabIndex = 142
        Me.Label2.Text = "You selected:"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(41, 300)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(76, 17)
        Me.Label3.TabIndex = 141
        Me.Label3.Text = "You selected:"
        '
        'lblVegetable
        '
        Me.lblVegetable.BackColor = System.Drawing.SystemColors.Control
        Me.lblVegetable.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblVegetable.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVegetable.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblVegetable.Location = New System.Drawing.Point(393, 188)
        Me.lblVegetable.Name = "lblVegetable"
        Me.lblVegetable.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblVegetable.Size = New System.Drawing.Size(97, 16)
        Me.lblVegetable.TabIndex = 135
        Me.lblVegetable.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblVScrollValue
        '
        Me.lblVScrollValue.BackColor = System.Drawing.SystemColors.Control
        Me.lblVScrollValue.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblVScrollValue.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVScrollValue.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblVScrollValue.Location = New System.Drawing.Point(385, 348)
        Me.lblVScrollValue.Name = "lblVScrollValue"
        Me.lblVScrollValue.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblVScrollValue.Size = New System.Drawing.Size(113, 17)
        Me.lblVScrollValue.TabIndex = 148
        Me.lblVScrollValue.Text = "Move the Scroll Bar"
        Me.lblVScrollValue.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'btnClose
        '
        Me.btnClose.BackColor = System.Drawing.SystemColors.Control
        Me.btnClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnClose.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.Location = New System.Drawing.Point(225, 324)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btnClose.Size = New System.Drawing.Size(81, 33)
        Me.btnClose.TabIndex = 145
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'hsbHorizontal
        '
        Me.hsbHorizontal.Cursor = System.Windows.Forms.Cursors.Default
        Me.hsbHorizontal.Location = New System.Drawing.Point(205, 214)
        Me.hsbHorizontal.Name = "hsbHorizontal"
        Me.hsbHorizontal.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.hsbHorizontal.Size = New System.Drawing.Size(113, 17)
        Me.hsbHorizontal.TabIndex = 137
        Me.hsbHorizontal.TabStop = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.vsbVertical)
        Me.GroupBox1.Location = New System.Drawing.Point(401, 220)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(80, 120)
        Me.GroupBox1.TabIndex = 147
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "VScrollBar"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(401, 168)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(81, 20)
        Me.Label1.TabIndex = 134
        Me.Label1.Text = "You selected:"
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.Controls.Add(Me.chkCheckBox)
        Me.Frame1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(193, 60)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(145, 65)
        Me.Frame1.TabIndex = 132
        Me.Frame1.TabStop = False
        Me.Frame1.Text = "CheckBox"
        '
        'Frame3
        '
        Me.Frame3.BackColor = System.Drawing.SystemColors.Control
        Me.Frame3.Controls.Add(Me.lstVegetables)
        Me.Frame3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame3.Location = New System.Drawing.Point(377, 60)
        Me.Frame3.Name = "Frame3"
        Me.Frame3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame3.Size = New System.Drawing.Size(121, 105)
        Me.Frame3.TabIndex = 136
        Me.Frame3.TabStop = False
        Me.Frame3.Text = "ListBox"
        '
        'Frame5
        '
        Me.Frame5.BackColor = System.Drawing.SystemColors.Control
        Me.Frame5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame5.Location = New System.Drawing.Point(189, 190)
        Me.Frame5.Name = "Frame5"
        Me.Frame5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame5.Size = New System.Drawing.Size(145, 57)
        Me.Frame5.TabIndex = 144
        Me.Frame5.TabStop = False
        Me.Frame5.Text = "HScrollBar"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(514, 379)
        Me.Controls.Add(Me.Frame2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.lblPet)
        Me.Controls.Add(Me.lblOption)
        Me.Controls.Add(Me.lblHScrollValue)
        Me.Controls.Add(Me.Frame4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblVegetable)
        Me.Controls.Add(Me.lblVScrollValue)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.hsbHorizontal)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Frame1)
        Me.Controls.Add(Me.Frame3)
        Me.Controls.Add(Me.Frame5)
        Me.Name = "Form1"
        Me.Text = "Controls Demo"
        Me.Frame2.ResumeLayout(False)
        Me.Frame4.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.Frame1.ResumeLayout(False)
        Me.Frame3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Public WithEvents Frame2 As System.Windows.Forms.GroupBox
    Public WithEvents cboPets As System.Windows.Forms.ComboBox
    Public WithEvents Label4 As System.Windows.Forms.Label
    Public WithEvents lblPet As System.Windows.Forms.Label
    Public WithEvents lblOption As System.Windows.Forms.Label
    Public WithEvents lblHScrollValue As System.Windows.Forms.Label
    Public WithEvents Frame4 As System.Windows.Forms.GroupBox
    Public WithEvents radOption1 As System.Windows.Forms.RadioButton
    Public WithEvents radOption3 As System.Windows.Forms.RadioButton
    Public WithEvents radOption2 As System.Windows.Forms.RadioButton
    Public WithEvents lstVegetables As System.Windows.Forms.ListBox
    Public WithEvents chkCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents vsbVertical As System.Windows.Forms.VScrollBar
    Public WithEvents Label2 As System.Windows.Forms.Label
    Public WithEvents Label3 As System.Windows.Forms.Label
    Public WithEvents lblVegetable As System.Windows.Forms.Label
    Public WithEvents lblVScrollValue As System.Windows.Forms.Label
    Public WithEvents btnClose As System.Windows.Forms.Button
    Public WithEvents hsbHorizontal As System.Windows.Forms.HScrollBar
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Public WithEvents Label1 As System.Windows.Forms.Label
    Public WithEvents Frame1 As System.Windows.Forms.GroupBox
    Public WithEvents Frame3 As System.Windows.Forms.GroupBox
    Public WithEvents Frame5 As System.Windows.Forms.GroupBox

End Class
